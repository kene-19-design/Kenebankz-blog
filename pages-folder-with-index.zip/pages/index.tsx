import React from 'react';

export default function Home() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '2rem' }}>
      <h1>Welcome to Kenebankz Blog</h1>
      <p>This is the homepage. 🎉</p>
    </div>
  );
}
